//
//  VSVideoRelatedCourseCell.h
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VSVideoRelatedCourseCell : UITableViewCell

@property (nonatomic) IBOutlet UIImageView *coverImageView;
@property (nonatomic) IBOutlet UILabel *nameLabel;
@property (nonatomic) IBOutlet UILabel *teacherLabel;
@property (nonatomic) IBOutlet UILabel *countForPeopleLabel;

@end

NS_ASSUME_NONNULL_END
