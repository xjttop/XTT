//
//  VSVideoSubtitleCell.m
//  VSchool
//
//  Created by liguoliang on 2020/2/13.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSVideoSubtitleCell.h"
@interface VSVideoSubtitleCell()
@property (weak, nonatomic) IBOutlet UILabel *stTimeLabel;
//@property (weak, nonatomic) IBOutlet UILabel *edTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@end

@implementation VSVideoSubtitleCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setStTime:(NSString *)stTime {
    _stTime = stTime;
    self.stTimeLabel.text = self.stTime;
}

//- (void)setEdTime:(NSString *)edTime {
//    _edTime = edTime;
//    self.edTimeLabel.text = self.edTime;
//}

- (void)setContent:(NSString *)content {
    _content = content;
    self.contentLabel.text = self.content;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if(self.isSelected){
        self.stTimeLabel.textColor = [UIColor colorWithHex:0x1962E8];
//        self.edTimeLabel.textColor = [UIColor colorWithHex:0x1962E8];
        self.contentLabel.textColor = [UIColor colorWithHex:0x1962E8];
    }else{
        self.stTimeLabel.textColor = [UIColor colorWithHex:0x666666];
//        self.edTimeLabel.textColor = [UIColor colorWithHex:0x666666];
        self.contentLabel.textColor = [UIColor colorWithHex:0x666666];
    }
}

@end
