//
//  VSVideoRelatedCourseCell.m
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSVideoRelatedCourseCell.h"
@interface VSVideoRelatedCourseCell()
@property (weak, nonatomic) IBOutlet UIImageView *fireImageView;

@end
@implementation VSVideoRelatedCourseCell

- (void)awakeFromNib {
    [super awakeFromNib];
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    self.fireImageView.image = [UIImage imageNamed:@"WDCCourseResource.bundle/icon_fire" inBundle:bundle withConfiguration:nil];
    // Initialization code
}


@end
