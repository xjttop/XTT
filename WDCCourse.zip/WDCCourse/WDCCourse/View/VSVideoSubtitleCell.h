//
//  VSVideoSubtitleCell.h
//  VSchool
//
//  Created by liguoliang on 2020/2/13.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VSVideoSubtitleCell : UITableViewCell
@property (nonatomic) NSString *stTime;
@property (nonatomic) NSString *edTime;
@property (nonatomic) NSString *content;
@end

NS_ASSUME_NONNULL_END
