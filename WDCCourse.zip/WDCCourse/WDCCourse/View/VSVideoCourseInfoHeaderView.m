//
//  VSVideoCourseInfoHeaderView.m
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSVideoCourseInfoHeaderView.h"
@interface VSVideoCourseInfoHeaderView()
@property (weak, nonatomic) IBOutlet UIStackView *masterTeacherStackView;
@property (weak, nonatomic) IBOutlet UILabel *teacherLabel;
@property (weak, nonatomic) IBOutlet UIImageView *teacherImageView;
@property (weak, nonatomic) IBOutlet UIImageView *labelImageView;
@property (weak, nonatomic) IBOutlet UIImageView *fireImageView;
@end
@implementation VSVideoCourseInfoHeaderView
- (void)setTeacherName:(NSString *)teacherName {
    _teacherName = teacherName;
    self.teacherLabel.text = _teacherName;
    if(_teacherName == nil || _teacherName.length == 0){
        self.masterTeacherStackView.hidden = YES;
    }else{
        self.masterTeacherStackView.hidden = NO;
    }
}
- (void)awakeFromNib {
    [super awakeFromNib];
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    self.teacherImageView.image = [UIImage imageNamed:@"WDCCourseResource.bundle/icon_teacher" inBundle:bundle withConfiguration:nil];
    self.labelImageView.image = [UIImage imageNamed:@"WDCCourseResource.bundle/icon_label" inBundle:bundle withConfiguration:nil];
    self.fireImageView.image = [UIImage imageNamed:@"WDCCourseResource.bundle/icon_fire" inBundle:bundle withConfiguration:nil];
    // Initialization code
}
@end

