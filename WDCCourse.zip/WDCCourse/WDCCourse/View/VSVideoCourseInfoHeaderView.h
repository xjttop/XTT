//
//  VSVideoCourseInfoHeaderView.h
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VSVideoCourseInfoHeaderView : UITableViewHeaderFooterView
@property (nonatomic) NSString *teacherName;
@property (weak, nonatomic) IBOutlet UILabel *fromSchoolLabel;
@property (weak, nonatomic) IBOutlet UILabel *countForPeopleLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

NS_ASSUME_NONNULL_END
