//
//  VSVideoRelatedCourseHeader.m
//  VSchool
//
//  Created by liguoliang on 2020/1/19.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSVideoRelatedCourseHeader.h"
@interface VSVideoRelatedCourseHeader()
@property (weak, nonatomic) IBOutlet UIButton *orderTimeButton;
@property (weak, nonatomic) IBOutlet UIButton *orderHotButton;
@end

@implementation VSVideoRelatedCourseHeader
- (void)awakeFromNib {
    [super awakeFromNib];
    [self onClickOrderByTime:self.orderTimeButton];
}
- (IBAction)onClickOrderByTime:(UIButton *)sender {
    sender.enabled = NO;
    self.orderHotButton.enabled = YES;
    if(self.handleChangeOrderBy){
        self.handleChangeOrderBy(0);
    }
}

- (IBAction)onClickOrderByHot:(UIButton *)sender {
    sender.enabled = NO;
    self.orderTimeButton.enabled = YES;
    if(self.handleChangeOrderBy){
        self.handleChangeOrderBy(2);
    }
}


@end
