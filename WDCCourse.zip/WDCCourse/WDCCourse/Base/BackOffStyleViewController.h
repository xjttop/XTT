//
//  BackOffStyleViewController.h
//  PepDoctor
//
//  Created by coactsoft_mac1 on 15/11/26.
//  Copyright © 2015年 coactsoft_mac1. All rights reserved.
//

#import "BaseViewController.h"

@interface BackOffStyleViewController : BaseViewController
- (void)navigationWhiteStyleWithViewController:(UIViewController *)viewcontroller;
- (void)navigationBlueStyleWithViewController:(UIViewController *)viewcontroller;
- (void)backOff;
- (void)backBtnWithCustomBackImage:(UIImage *)backimage action:(SEL)action;
@end
