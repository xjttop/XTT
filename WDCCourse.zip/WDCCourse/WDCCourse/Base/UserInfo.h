//
//  UserInfo.h
//  OA
//
//  Created by 宋彬彬 on 2018/4/11.
//  Copyright © 2018年 Evil. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface UserInfo : NSObject

@property (strong, nonatomic) NSString *access_token;

+ (instancetype)userInfo;

/** 获取token */
+ (void)setToken:(NSString *)value;
+ (NSString *)getToken;

@end
