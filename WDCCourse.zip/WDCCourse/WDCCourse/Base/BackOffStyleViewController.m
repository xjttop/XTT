//
//  BackOffStyleViewController.m
//  PepDoctor
//
//  Created by coactsoft_mac1 on 15/11/26.
//  Copyright © 2015年 coactsoft_mac1. All rights reserved.
//

#import "BackOffStyleViewController.h"
#import "UIColor+SMAddition.h"
@interface BackOffStyleViewController () <UINavigationControllerDelegate, RouterProtocol>

@property (nonatomic, assign) BOOL isDidDisappear;
@property (nonatomic) BOOL isCustomNavStyle;

@end

@implementation BackOffStyleViewController

- (instancetype)initWithRouterWithParams:(NSDictionary *)params {
    if ([self init]) {
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.navigationController.viewControllers.count > 1) {
        [self backBtnWithCustomBackImage:nil action:nil];
    }
    // nav样式
    [self navigationWhiteStyleWithViewController:self];
    // 暗色样式
    [self traitCollectionStyle];
}

- (BOOL)prefersStatusBarHidden {
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    if (@available(iOS 13.0, *)) {
        return UIStatusBarStyleDarkContent;
    }
    else {
        return UIStatusBarStyleDefault;
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.hidesBottomBarWhenPushed = YES;
    if (self.navigationController.tabBarController) {
        self.navigationController.viewControllers.firstObject.hidesBottomBarWhenPushed = NO;
    }
//    if(self.isCustomNavStyle == NO) {
//        [self navigationWhiteStyleWithViewController:self];
//    }
    if (self.navigationController || self.modalPresentationStyle == UIModalPresentationFullScreen) {
        if (self.isDidDisappear) {
            [self navigationWhiteStyleWithViewController:self];
        }
    }
}

- (void)navigationWhiteStyleWithViewController:(UIViewController *)viewcontroller {
    if (viewcontroller) {
        self.isCustomNavStyle = YES;
        viewcontroller.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        viewcontroller.navigationController.navigationBar.tintColor = color_three;
        viewcontroller.navigationController.navigationBar.titleTextAttributes = @{
                NSForegroundColorAttributeName: color_three
        };
        viewcontroller.navigationController.delegate = self;
        viewcontroller.navigationController.navigationBar.translucent = NO;
        viewcontroller.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

- (void)navigationBlueStyleWithViewController:(UIViewController *)viewcontroller {
    if (viewcontroller) {
        self.isCustomNavStyle = YES;
        viewcontroller.navigationController.navigationBar.barTintColor = color_main;
        viewcontroller.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        viewcontroller.navigationController.navigationBar.titleTextAttributes = @{
                NSForegroundColorAttributeName: [UIColor whiteColor]
        };
        viewcontroller.navigationController.delegate = self;
        viewcontroller.navigationController.navigationBar.translucent = NO;
        viewcontroller.navigationController.navigationBar.shadowImage = [UIImage new];
    }
}

- (void)traitCollectionStyle {
    UIColor *color = [UIColor colorWithHex:0xEFEFEF];
    if (@available(iOS 13, *)) {
        color = [UIColor colorWithDynamicProvider: ^UIColor *_Nonnull (UITraitCollection *_Nonnull traitCollection) {
            if (traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark) {
                return [UIColor blackColor];
            }
            else {
                return [UIColor colorWithHex:0xEFEFEF];
            }
        }];
        if (UITraitCollection.currentTraitCollection.userInterfaceStyle == UIUserInterfaceStyleDark) {
            if (self.view.backgroundColor != [UIColor clearColor] || self.navigationController != nil) {
                self.view.backgroundColor = color;
            }
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.isDidDisappear = YES;
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    self.isDidDisappear = NO;
}

- (void)backBtnWithCustomBackImage:(UIImage *)backimage action:(SEL)action {
    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 68, 40)];
    backBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    backBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -50, 0, 0);
    if (backimage == nil) {
        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
        [backBtn setImage:[UIImage imageNamed:@"WDCCourseResource.bundle/nav_Return_black" inBundle:bundle withConfiguration:nil] forState:UIControlStateNormal];
        //[backBtn setImage:[UIImage imageNamed:@"currency_nav_Return_black"] forState:UIControlStateNormal];
    }
    else {
        [backBtn setImage:backimage forState:UIControlStateNormal];
    }
    if (action != nil) {
        [backBtn addTarget:self action:action forControlEvents:UIControlEventTouchDown];
    }
    else {
        [backBtn addTarget:self action:@selector(backOff)forControlEvents:UIControlEventTouchDown];
    }
    UIBarButtonItem *leftBtn = [[UIBarButtonItem alloc]initWithCustomView:backBtn];
    UIBarButtonItem *flexBtn = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    flexBtn.width = -10;//正数往左移，负数往右移
    self.navigationItem.leftBarButtonItems = @[leftBtn];
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}

- (void)backOff {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
