//
//  BaseViewController.h
//  OA
//
//  Created by 宋彬彬 on 2018/4/11.
//  Copyright © 2018年 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController <UIGestureRecognizerDelegate>
- (BOOL)isNavigationHidden;
@end
