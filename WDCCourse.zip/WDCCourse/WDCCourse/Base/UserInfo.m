//
//  UserInfo.m
//  OA
//
//  Created by 宋彬彬 on 2018/4/11.
//  Copyright © 2018年 Evil. All rights reserved.
//

#import "UserInfo.h"
@implementation UserInfo

+ (instancetype)userInfo {
    static dispatch_once_t onceToken;
    static UserInfo *userInfo;
    dispatch_once(&onceToken, ^{
        userInfo = [[UserInfo alloc] init];
    });
    return userInfo;
}

//token
+ (void)setToken:(NSString *)value {
    NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
    [defaults setObject:value forKey:@"Token"];
}

+ (NSString *)getToken {
    NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
    return [defaults objectForKey:@"Token"];
}

@end
