//
//  NetworkConfig.m
//  VSchool
//
//  Created by liguoliang on 2019/12/12.
//  Copyright © 2019 Evil. All rights reserved.
//

#import "NetworkConfig.h"

@implementation NetworkConfig

- (NSDictionary *)requestHeaderWithPath:(NSString *)path {
    NSString *token = [NSString stringWithFormat:@"vschoolparent%@", [UserInfo getToken]];
    NSLog(@"-[%s]-TOKEN:%@", __func__, token);
    return @{
        @"X-vschool-auth-token": token
    };
}

- (NSString *)requestHost {
//    NSUserDefaults *defaults =[NSUserDefaults standardUserDefaults];
//    NSString *host = [NSString stringWithFormat:@"%@", [defaults objectForKey:@"host"]];
//    return host;
    return [GLEnvs loadEnv][@"host"];
}

- (NSTimeInterval)requestTimeout {
    return 15;
}

- (BOOL)isDebugMode {
#ifdef DEBUG
    return YES;
#endif
    return NO;
}
- (void)logMessage:(NSString *)msg {
    NSLog(@"%@", msg);
}

- (NSError *)interceptWithURL:(NSString *)url Header:(NSHTTPURLResponse *)header Success:(id)data Failed:(NSError *)error {
    NSError *userError = nil;
    if (error) {
        userError = error;
    }
    else {
        if ([data isKindOfClass:[NSDictionary class]] && data[@"status"]) {
            int status = [data[@"status"] intValue];
            if (status != 0) {
                userError = [NSError errorWithDomain:data[@"message"]
                                                code:status
                                            userInfo:data ? @{ @"data": data } : nil];
            }
            switch (status) {
                case 0: // 正常
                    userError = nil;
                    break;
                case -4000:  // 需要去充值- 不提示
                    break;
                case -6000: // 拍搜结果错误
                    [[SMWarningView sharedManager] displayPromptWithString:userError.domain color:[UIColor colorWithRed:250/255.0 green:225/255.0 blue:150/255.0 alpha:1.0]];
                    break;
                default:    // 异常错误- Message提示
                    if (data[@"message"]) {
                        userError = [NSError errorWithDomain:data[@"message"] code:status userInfo:data ? @{ @"data": data } : nil];
                    }
                    else {
                        userError = [NSError errorWithDomain:[NSString stringWithFormat:@"服务器开小差了~请稍后再试~(%@)", data[@"status"]] code:status userInfo:data ? @{ @"data": data } : nil];
                    }
                    [[SMWarningView sharedManager] displayWarningWithString:userError.domain];
                    break;
            }
        }
    }
    return userError;
}

@end
