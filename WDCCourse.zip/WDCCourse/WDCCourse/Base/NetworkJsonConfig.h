//
//  NetworkJsonConfig.h
//  VSchool
//
//  Created by liguoliang on 2020/1/9.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "NetworkConfig.h"

NS_ASSUME_NONNULL_BEGIN

@interface NetworkJsonConfig : NetworkConfig

@end

NS_ASSUME_NONNULL_END
