//
//  BaseViewController.m
//  OA
//
//  Created by 宋彬彬 on 2018/4/11.
//  Copyright © 2018年 Evil. All rights reserved.
//

#import "BaseViewController.h"
//#import <IQKeyboardManager.h>

@interface BaseViewController ()

//@property (nonatomic, strong) IQKeyboardReturnKeyHandler *returnKeyHandler;

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
//    keyboardManager.enable = YES; // 控制整个功能是否启用
//    keyboardManager.shouldResignOnTouchOutside = YES; // 控制点击背景是否收起键盘
//    keyboardManager.enableAutoToolbar = YES; // 控制是否显示键盘上的工具条
//    keyboardManager.shouldShowToolbarPlaceholder = YES; // 是否显示占位文字
//    keyboardManager.keyboardDistanceFromTextField = 75.0f; // 输入框距离键盘的距离
//
//    self.returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
//    self.returnKeyHandler.lastTextFieldReturnKeyType = UIReturnKeyDone;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    [self.navigationController setNavigationBarHidden:[self isNavigationHidden] animated:animated];
}

- (BOOL)isNavigationHidden {
    return NO;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if(self.navigationController.viewControllers.count>1){
        return YES;
    }
    return NO;
}

/** presentStyle -> FullScreen (如果不是 OverCurrentContext 或 CurrentContext) */
- (void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completion {
    UIModalPresentationStyle presentStyle = viewControllerToPresent.modalPresentationStyle;
    if(presentStyle != UIModalPresentationOverCurrentContext && presentStyle != UIModalPresentationCurrentContext){
        presentStyle = UIModalPresentationFullScreen;
    }
    viewControllerToPresent.modalPresentationStyle = presentStyle;
    [super presentViewController:viewControllerToPresent animated:flag completion:completion];
}

- (void)dealloc {
    //self.returnKeyHandler = nil;
}

@end
