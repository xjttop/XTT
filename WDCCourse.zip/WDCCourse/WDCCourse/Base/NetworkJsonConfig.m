//
//  NetworkJsonConfig.m
//  VSchool
//
//  Created by liguoliang on 2020/1/9.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "NetworkJsonConfig.h"

@implementation NetworkJsonConfig
- (BOOL)isJsonParams {
    return YES;
}
@end
