//
//  NetworkConfig.h
//  VSchool
//
//  Created by liguoliang on 2019/12/12.
//  Copyright © 2019 Evil. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GLNetworkPotocol.h>
NS_ASSUME_NONNULL_BEGIN

@interface NetworkConfig : NSObject <GLNetworkPotocol>

@end

NS_ASSUME_NONNULL_END
