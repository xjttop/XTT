//
//  VSVideoCourseViewController.h
//  VSchool
//
//  Created by liguoliang on 2019/12/19.
//  Copyright © 2019 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BackOffStyleViewController.h"
NS_ASSUME_NONNULL_BEGIN

@interface VSVideoCourseViewController : BackOffStyleViewController
@property (nonatomic) NSString *masterCourseId; // 名师课ID
@property(nonatomic, copy) NSString *studentId;
@property(nonatomic, copy) NSString *token;
@property(nonatomic, copy) NSString *host;
@end

NS_ASSUME_NONNULL_END
