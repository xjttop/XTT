//
//  LearningReportViewController.m
//  WDCCourse
//
//  Created by Xjt on 2020/11/13.
//

#import "VSWebViewController.h"
#import "VSVideoCourseViewController.h"
@interface VSWebViewController ()<WKScriptMessageHandler>
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic) WKWebViewConfiguration *config;
@property (nonatomic) WKUserContentController *contentController;
@property (nonatomic) NSArray<NSString *> *jsfuncs;
- (void)registerJSInvokeList:(NSArray<NSString *> *)jsFuncs;
@end

@implementation VSWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [UserInfo setToken:self.token];
    GLEnvs *envs = [GLEnvs defaultWithEnvironments:@[
                        @{ @"测试环境": @{
                               @"host": @"http://39.106.80.105:8082",
                               @"webhost": @"http://39.106.80.105:8092"
                        } },
                        @{ @"正式环境": @{
                               @"host": @"https://mparent.xlsxedu.com",
                               @"webhost": @"https://webview.xlsxedu.com"
                        } }
    ]];
    [envs enableChangeEnvironment:YES withSelectIndex:0];
    [GLNetworking managerWithConfig:[[NetworkConfig alloc]init]];
    [self registerJSInvokeList:@[
        @"getLikeQuestionData",
        @"getTeacherClassData",
        @"goBackView"]];
    NSString *tokenEncode = [[UserInfo getToken] stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet alphanumericCharacterSet]];
    if ([self.pageTitle isEqualToString:@"学情报告"]) {
        self.url = [NSString stringWithFormat:@"%@/academicreport?token=%@&studentId=%@&type=ios", [GLEnvs loadEnv][@"webhost"], tokenEncode, self.studentId];
    }
    NSLog(@"-[%s]-请求地址：%@", __func__, self.url);
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.url]]];
    self.title = self.pageTitle;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.webView.frame = self.view.bounds;
}
- (void)backOff {
    //判断是否能返回到H5上级页面
    if (self.webView.canGoBack==YES) {
        //返回上级页面
        [self.webView goBack];
    }else{
        //退出控制器
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (WKWebView *)webView {
    if (!_webView) {
        _webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:self.config];
        _webView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_webView];
    }
    return _webView;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self registerJSInvokeList:self.jsfuncs];
    if ([self.pageTitle isEqualToString:@"学情报告"]) {
        NSLog(@"---%@",self.pageTitle);
        [self.navigationController setNavigationBarHidden:YES animated:animated];
    }else{
        [self.navigationController setNavigationBarHidden:NO animated:animated];
    }
   
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    for(NSString *name in self.jsfuncs){
        [self.contentController removeScriptMessageHandlerForName:name];
    }
//    if ([self.title isEqualToString:@" 学情报告"]) {
//        [self.navigationController setNavigationBarHidden:YES animated:animated];
//    }
  
}

- (void)registerJSInvokeList:(NSArray<NSString *> *)jsFuncs {
    if(jsFuncs && jsFuncs.count>0){
        self.contentController = [[WKUserContentController alloc] init];
        for(NSString *name in jsFuncs){
            [self.contentController addScriptMessageHandler:self name:name];
        }
        self.config.userContentController = self.contentController;
        self.jsfuncs = jsFuncs;
    }
}
- (void)invokeJSFuncName:(NSString *)name completionHandle:(void(^)(id, NSError *error))handle {
    [self.webView evaluateJavaScript:name completionHandler:handle];
}
- (WKWebViewConfiguration *)config {
    if(!_config){
        _config = [[WKWebViewConfiguration alloc]init];
    }
    return _config;
}
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(nonnull WKScriptMessage *)message {
    if ([message.name isEqualToString:@"getLikeQuestionData"]) {
        VSWebViewController *webViewController = [VSWebViewController new];
        webViewController.pageTitle = @"相似题";
        webViewController.url = [NSString stringWithFormat:@"%@/checkmistake/similar?token=%@&questionId=%@&type=ios", [GLEnvs loadEnv][@"webhost"], [UserInfo getToken], message.body[@"params"]];
        [self.navigationController pushViewController:webViewController animated:YES];
    }
    else if ([message.name isEqualToString:@"getTeacherClassData"]) {
        NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"WDCCourseResource" ofType:@"bundle"]];
        NSString *masterCourseIdStr = [NSString stringWithFormat:@"%@", message.body[@"params"]];
        VSVideoCourseViewController *VC = [[VSVideoCourseViewController alloc]initWithNibName:@"VSVideoCourseViewController" bundle:bundle];
        VC.masterCourseId = masterCourseIdStr;
        VC.studentId = self.studentId;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if ([message.name isEqualToString:@"goBackView"]) {
        [self.navigationController popViewControllerAnimated:YES];
    }
}
//如果是H5页面里面自带的返回按钮处理如下:

#pragma mark - webViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
     NSString * requestString = [[request URL] absoluteString];
     requestString = [requestString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
     //获取H5页面里面按钮的操作方法,根据这个进行判断返回是内部的还是push的上一级页面
     if ([requestString hasPrefix:@"goback:"]) {
          [self.navigationController popViewControllerAnimated:YES];
     }else{
          [self.webView goBack];
     }
     return YES;
}

- (void)dealloc {
    NSLog(@"-----web--dealloc-----");
}
@end

