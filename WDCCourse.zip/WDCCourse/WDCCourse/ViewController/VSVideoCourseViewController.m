//
//  VSVideoCourseViewController.m
//  VSchool
//
//  Created by liguoliang on 2019/12/19.
//  Copyright © 2019 Evil. All rights reserved.
//

#import "VSVideoCourseViewController.h"
#import "VSVideoCourseInfoHeaderView.h"
#import "VSVideoRelatedCourseHeader.h"
#import "VSVideoCourse.h"
//#import "AppDelegate.h"
#import "UIDevice+OrientationExt.h"
#import "VSVideoRelatedCourseCell.h"
#import "ZFPlayer.h"
#import "ZFPlayerController.h"
#import "ZFPlayerControlView.h"
#import "ZFAVPlayerManager.h"
#import "NSArray+LRCStrExt.h"
#import "VSVideoLRC.h"
#import "VSVideoSubtitleCell.h"

#define kSize 10

@interface VSVideoCourseViewController () <UITableViewDelegate, UITableViewDataSource>
{
    NSInteger pageNum;    // 页码
    BOOL didLearned;    // 是否学完
    CFTimeInterval enterTime;    //进入时间
    UIImageView *imageView; //emptyImage
    UILabel *label; //emptylabel
}
@property (weak, nonatomic) IBOutlet UIImageView *videoPreviewImageView;
@property (weak, nonatomic) IBOutlet UIScrollView *areaScrollView;
@property (weak, nonatomic) IBOutlet UITableView *relatedTableView;
@property (weak, nonatomic) IBOutlet UITableView *subtitleTableView;
@property (weak, nonatomic) IBOutlet UIButton *videoPlayButton;
@property (weak, nonatomic) IBOutlet UIView *videoContainer;
@property (weak, nonatomic) IBOutlet UIView *switchView;
@property (weak, nonatomic) IBOutlet UIButton *buttonVideoInfo;
@property (weak, nonatomic) IBOutlet UIButton *buttonVideoSubtitle;
@property (nonatomic, strong) ZFPlayerController *player;
@property (nonatomic, strong) ZFPlayerControlView *controlView;
@property (nonatomic) BOOL hasSubtitle; // 是否包含字幕
@property (nonatomic) NSInteger subindex;  // 字幕自动滚动索引值
@property (nonatomic) NSString *videoSubtitle;
@property (nonatomic) VSVideoCourse *videoCourse;
@property (nonatomic) NSMutableArray<VSVideoCourse *> *relatedDatas;
@property (nonatomic) NSArray<VSVideoLRC *> *subtitleDatas; // 字幕内容
@property (nonatomic) NSInteger order;
@property (nonatomic) NSMutableDictionary *params;
@end

@implementation VSVideoCourseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    pageNum = 1;
    self.switchView.hidden = YES;
    self.buttonVideoInfo.selected = YES;
    NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    self.videoPreviewImageView.image = [UIImage imageNamed:@"WDCCourseResource.bundle/videoCourse_bg" inBundle:bundle withConfiguration:nil];
    [self.videoPlayButton setImage:[UIImage imageNamed:@"WDCCourseResource.bundle/icon_player" inBundle:bundle withConfiguration:nil] forState:UIControlStateNormal];
    [self setupRelatedTableView];
    [self loadVideoData];
    [self loadRelatedDataWithOrderBy:0];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (enterTime == 0) {
        enterTime = CACurrentMediaTime();
    }
    self.params = [NSMutableDictionary dictionary];
    self.params[@"progressBarTime"] = @"0";
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    //((AppDelegate *)[UIApplication sharedApplication].delegate).allowRotation = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    //((AppDelegate *)[UIApplication sharedApplication].delegate).allowRotation = NO;
}

// 构建
- (void)setupVideoSubtitleTableView {
    self.subindex = -1;
    self.subtitleTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.subtitleTableView.delegate = self;
    self.subtitleTableView.dataSource = self;
    //NSBundle *bundle = [NSBundle bundleForClass:[self class]];
    NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"WDCCourseResource" ofType:@"bundle"]];
    [self.subtitleTableView registerNib:[UINib nibWithNibName:@"VSVideoSubtitleCell" bundle:bundle] forCellReuseIdentifier:@"VSVideoSubtitleCell"];
    //[self.subtitleTableView registerNib:[UINib nibWithNibName:@"VSVideoSubtitleCell" bundle:nil] forCellReuseIdentifier:@"VSVideoSubtitleCell"];
    NSString *subString = [NSString stringWithContentsOfURL:[NSURL URLWithString:self.videoCourse.subtitle] encoding:NSUTF8StringEncoding error:nil];
    self.subtitleDatas = [NSArray createWithLRCString:subString];
}

- (void)setupRelatedTableView {
    NSBundle *bundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"WDCCourseResource" ofType:@"bundle"]];
    [self.relatedTableView registerNib:[UINib nibWithNibName:@"VSVideoRelatedCourseCell" bundle:bundle] forCellReuseIdentifier:@"VSVideoRelatedCourseCell"];
    [self.relatedTableView registerNib:[UINib nibWithNibName:@"VSVideoCourseInfoHeaderView" bundle:bundle] forHeaderFooterViewReuseIdentifier:@"VSVideoCourseInfoHeaderView"];
    [self.relatedTableView registerNib:[UINib nibWithNibName:@"VSVideoRelatedCourseHeader" bundle:bundle] forHeaderFooterViewReuseIdentifier:@"VSVideoRelatedCourseHeader"];
    self.relatedTableView.delegate = self;
    self.relatedTableView.dataSource = self;
    self.relatedTableView.tableFooterView = [UIView new];
    self.relatedTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    __weak typeof(self) wself = self;
    self.relatedTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock: ^{
        __strong typeof(wself) self = wself;
        [self loadRelatedDataWithOrderBy:self.order];
    }];
    self.relatedTableView.mj_footer.hidden = YES;
}

// 上传视频进度
- (void)uploadVideoProgerss {
    self.params[@"learnedCompleted"] = [NSString stringWithFormat:@"%d", didLearned];//是否学完
    self.params[@"miniCourseId"] = self.masterCourseId;     //微课id
    self.params[@"studentId"] = self.studentId;
    //[NSString stringWithFormat:@"%@", [UserInfo getStudent].id];//学生id
    self.params[@"watchTime"] = [NSString stringWithFormat:@"%ld", (long)self.videoCourse.systemTime];//服务器返回时间
    self.params[@"watchTimeLength"] = [NSString stringWithFormat:@"%ld", (long)(CACurrentMediaTime() - enterTime)];
    if ([self.params[@"progressBarTime"] floatValue] > 0) {
       NetworkJsonConfig *net = [[NetworkJsonConfig alloc]init];
        [net requestHost];
        [GLNetworking.POST().config([[NetworkJsonConfig alloc] init]).path(@"/app/videoWatchFlow").params(self.params) success: ^(NSURLResponse *header, id response) {
            [[SMWarningView sharedManager] displayPromptWithString:response[@"result"]];
        } failure: ^(NSError *error, NSURLResponse *response, id data) {
            [[SMWarningView sharedManager] displayWarningWithString:error.domain];
        }  complete:nil];
    }
}

// 播放视频
- (void)startVideoPlayer {
    if (self.videoCourse.video) {
        ZFAVPlayerManager *playerManager = [[ZFAVPlayerManager alloc] init];
        self.player = [ZFPlayerController playerWithPlayerManager:playerManager containerView:self.videoContainer];
        self.player.controlView = self.controlView;
        self.player.forceDeviceOrientation = YES;
        self.player.pauseWhenAppResignActive = NO;
        self.player.assetURL = [NSURL URLWithString:self.videoCourse.video];
        
        if(self.videoCourse.targeted) {
            NSMutableArray *dotstemp = [NSMutableArray arrayWithCapacity:self.videoCourse.processDots.count];
            for(int i = 0;i<self.videoCourse.processDots.count;i++){
                float dotRatio = (float)self.videoCourse.processDots[i].time / self.videoCourse.totalTimeLength;
                [dotstemp addObject:[NSNumber numberWithFloat:dotRatio]];
            }
            ((ZFPlayerControlView *)self.player.controlView).portraitControlView.slider.dots = [dotstemp copy];
            ((ZFPlayerControlView *)self.player.controlView).landScapeControlView.slider.dots = [dotstemp copy];
        }
        
        @weakify(self)
        self.player.orientationWillChange = ^(ZFPlayerController *_Nonnull player, BOOL isFullScreen) {
            @strongify(self)
            [self setNeedsStatusBarAppearanceUpdate];
        };
        self.player.playerDidToEnd = ^(id _Nonnull asset) {
            NSLog(@"playerDidToEnd");
            @strongify(self)
            if (self->didLearned == NO) {
                self->didLearned = YES;
            }
            [self.player stop];
            self.videoPlayButton.hidden = NO;
        };
        self.player.presentationSizeChanged = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, CGSize size) {
            NSLog(@"presentationSizeChanged");
        };
        self.player.playerPlayStateChanged = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, ZFPlayerPlaybackState playState) {
            @strongify(self)
            switch (playState) {
                case ZFPlayerPlayStatePlaying:
                    NSLog(@"ZFPlayerPlayStatePlaying");
                    self.videoPlayButton.hidden = YES;
                    break;
                case ZFPlayerPlayStatePaused:
                    NSLog(@"ZFPlayerPlayStatePaused");
                    self.videoPlayButton.hidden = NO;
                    break;
                case ZFPlayerPlayStateUnknown:
                    break;
                case ZFPlayerPlayStatePlayFailed:
                    break;
                case ZFPlayerPlayStatePlayStopped:
                    NSLog(@"ZFPlayerPlayStatePlayStopped");
                    break;
            }
        };

        self.player.playerPlayTimeChanged = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, NSTimeInterval currentTime, NSTimeInterval duration) {
            @strongify(self)
            NSDate *currentTimeDate = [NSDate dateWithTimeIntervalSince1970:currentTime];
            [self scrollVideoSubtitleToTime:currentTimeDate];
            self.params[@"progressBarTime"] = [NSString stringWithFormat:@"%.0f", currentTime];//播放进度
        };
        self.player.playerPrepareToPlay = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, NSURL *_Nonnull assetURL) {
            NSLog(@"playerPrepareToPlay");
        };
        self.player.playerReadyToPlay = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, NSURL *_Nonnull assetURL) {
            NSLog(@"playerReadyToPlay");
        };
        self.player.playerBufferTimeChanged = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, NSTimeInterval bufferTime) {
            NSLog(@"playerBufferTimeChanged");
        };
        self.player.playerLoadStateChanged = ^(id<ZFPlayerMediaPlayback>  _Nonnull asset, ZFPlayerLoadState loadState) {
            NSLog(@"playerLoadStateChanged");
        };
    }
}

// 自动滚动字幕
- (void)scrollVideoSubtitleToTime:(NSDate *)time {
    if (self.hasSubtitle == NO || !self.player.currentPlayerManager.isPlaying) {
        return;
    }
    __weak typeof(self) wself = self;
    [self.subtitleDatas enumerateObjectsUsingBlock: ^(VSVideoLRC *_Nonnull obj, NSUInteger idx, BOOL *_Nonnull stop) {
        __strong typeof(wself) self = wself;
        NSTimeInterval st = [obj.stTime timeIntervalSince1970];
        NSTimeInterval cu = [time timeIntervalSince1970];
        NSTimeInterval ed = [obj.edTime timeIntervalSince1970];
        
        if(st<=cu && cu<ed) {
            NSLog(@"%lu | %.1f|%.1f|%.1f\n%@", idx, st, cu, ed, obj.content);
            if (idx != self.subindex) {
                self.subindex = idx;
                [self.subtitleTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:self.subindex inSection:0] animated:YES scrollPosition:UITableViewScrollPositionMiddle];
            }
            *stop = YES;
        }
    }];
}

- (void)backOff {
    [self.navigationController popViewControllerAnimated:YES];
}

// 如果相关课程无内容，则显示提示信息
- (void)checkShowEmptyTipView {
    if (self.relatedDatas.count == 0) {
        if (self.relatedTableView.backgroundView == nil) {
            self.relatedTableView.backgroundView = [UIView new];
            NSBundle *bundle = [NSBundle bundleForClass:[self class]];
            imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"WDCCourseResource.bundle/noData" inBundle:bundle withConfiguration:nil]];
            //                imageView.frame = CGRectMake(0, 0, 210, 142);
            label = [UILabel new];
            label.text = @"暂无相关课程";
            label.font = [UIFont systemFontOfSize:12];
            label.textColor = [UIColor colorWithHex:0x999999];
            [label sizeToFit];
            [self.relatedTableView.backgroundView addSubview:imageView];
            [self.relatedTableView.backgroundView addSubview:label];
        }
        imageView.center = CGPointMake(UIScreen.mainScreen.bounds.size.width / 2, self.relatedTableView.center.y + 20);
        label.center = CGPointMake(imageView.center.x, CGRectGetMaxY(imageView.frame) + 20);
        self.relatedTableView.scrollEnabled = NO;
    }
    else {
        self.relatedTableView.backgroundView = nil;
        self.relatedTableView.scrollEnabled = YES;
    }
}

#pragma mark- Load
// 获取视频和详情
- (void)loadVideoData {
    [SVProgressHUD show];
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"id"] = self.masterCourseId;
    [GLNetworking.GET().path(@"/app/miniCourse/getMiniCourse").params(params) success: ^(NSURLResponse *header, id response) {
        label.text = [NSString stringWithFormat:@"%@",self.masterCourseId];
        self.videoCourse = [VSVideoCourse yy_modelWithJSON:response[@"result"]];
        self.title = self.videoCourse.name;
        if (self.videoCourse.cover) {
            [self.videoPreviewImageView sd_setImageWithURL:[NSURL URLWithString:self.videoCourse.cover]];
        }
        // 如果有字幕
        self.hasSubtitle = self.videoCourse.subtitled;
        // 更新视频详情
        [self.relatedTableView reloadData];
    } failure:^(NSError *error, NSURLResponse *response, id data) {
        
    } complete:^{
        [SVProgressHUD dismiss];
    }];
}

// 获取关联课程
- (void)loadRelatedDataWithOrderBy:(NSInteger)order {
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    params[@"page"] = [NSString stringWithFormat:@"%ld", pageNum];
    params[@"size"] = [NSString stringWithFormat:@"%d", kSize];
    params[@"id"] = self.masterCourseId;
    params[@"orderBy"] = [NSString stringWithFormat:@"%ld", (long)order];
    params[@"studentId"] = self.studentId;
    //[UserInfo getStudent].id;
    [GLNetworking.GET().path(@"/app/miniCourse/getRelatedMiniCourse").params(params) success: ^(NSURLResponse *header, id response) {
        NSLog(@"related complete");
        NSArray *tempArray = [NSArray yy_modelArrayWithClass:[VSVideoCourse class] json:response[@"result"]];
        if (self->pageNum == 1) {
            [self.relatedDatas removeAllObjects];
        }
        [self.relatedDatas addObjectsFromArray:tempArray];
        if ([response[@"totalElements"] intValue] > self.relatedDatas.count) {
            self->pageNum++;
            self.relatedTableView.mj_footer.hidden = NO;
            [self.relatedTableView.mj_footer endRefreshing];
        }
        else {
            [self.relatedTableView.mj_footer endRefreshingWithNoMoreData];
        }
        [self.relatedTableView reloadData];
    } failure:nil complete:^{
    }];
}

// 获取字幕内容
- (void)loadSubtitleData {
    if (self.hasSubtitle) {
        self.videoSubtitle = self.videoCourse.subtitle;
    }
}

#pragma mark- Event
- (IBAction)onClickVideoPlay:(UIButton *)sender {
    self.videoPreviewImageView.hidden = YES;
    [self startVideoPlayer];
}

// 点击简介按钮
- (IBAction)onClickButtonVideoInfo:(UIButton *)sender {
    self.buttonVideoSubtitle.selected = NO;
    sender.selected = YES;
    [self.areaScrollView scrollRectToVisible:self.relatedTableView.bounds animated:NO];
}

// 点击字幕按钮
- (IBAction)onClickButtonSubtitle:(UIButton *)sender {
    self.buttonVideoInfo.selected = NO;
    sender.selected = YES;
    [self.areaScrollView scrollRectToVisible:self.subtitleTableView.frame animated:NO];
}

#pragma mark- uitableview delegate datasource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.relatedTableView) {
        return 2;
    }
    else {
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.relatedTableView) {
        if (section == 0) {
            return 0;
        }
        return self.relatedDatas.count;
    }
    else {
        return self.subtitleDatas.count;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (tableView == self.relatedTableView) {
        if (section == 0) {
            VSVideoCourseInfoHeaderView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"VSVideoCourseInfoHeaderView"];
            header.titleLabel.text = self.videoCourse.name;
            header.teacherName = self.videoCourse.teacher.name;
            header.fromSchoolLabel.text = self.videoCourse.teacher.school.name;
            header.countForPeopleLabel.text = [NSString stringWithFormat:@"%ld人已学习", (long)self.videoCourse.learnedCount];
            return header;
        }
        else {
            VSVideoRelatedCourseHeader *relatedHeader = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"VSVideoRelatedCourseHeader"];
            __weak typeof(self) wself = self;
            relatedHeader.handleChangeOrderBy = ^(NSInteger order) {
                __strong typeof(wself) self = wself;
                if (self.relatedDatas.count > 0) {
                    [self.relatedTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1] atScrollPosition:UITableViewScrollPositionTop animated:NO];
                    self.order = order;
                    self->pageNum = 1;
                    [self loadRelatedDataWithOrderBy:order];
                }
            };
            [self checkShowEmptyTipView];
            return relatedHeader;
        }
    }
    else {
        return nil;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.relatedTableView) {
        VSVideoRelatedCourseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VSVideoRelatedCourseCell" forIndexPath:indexPath];
        VSVideoCourse *relatedCourse = self.relatedDatas[indexPath.row];
        NSBundle *bundle = [NSBundle bundleForClass:[self class]];
        [cell.coverImageView sd_setImageWithURL:[NSURL URLWithString:relatedCourse.cover] placeholderImage:[UIImage imageNamed:@"WDCCourseResource.bundle/videoCourse" inBundle:bundle withConfiguration:nil]];
        //[cell.coverImageView sd_setImageWithURL:[NSURL URLWithString:relatedCourse.cover] placeholderImage:[UIImage imageNamed:@"videoCourse_默认课程"]];
        cell.nameLabel.text = relatedCourse.name;
        cell.teacherLabel.text = relatedCourse.teacher.name;
        cell.countForPeopleLabel.text = [NSString stringWithFormat:@"%ld人已学习", (long)relatedCourse.learnedCount];
        return cell;
    }
    else {
        VSVideoSubtitleCell *videoSubtitleCell = [tableView dequeueReusableCellWithIdentifier:@"VSVideoSubtitleCell"];
        NSDateFormatter *df = [[NSDateFormatter alloc]init];
        df.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        df.dateFormat = @"HH:mm:ss";
        videoSubtitleCell.stTime = [df stringFromDate:self.subtitleDatas[indexPath.row].stTime];
        videoSubtitleCell.edTime = [df stringFromDate:self.subtitleDatas[indexPath.row].edTime];
        videoSubtitleCell.content = self.subtitleDatas[indexPath.row].content;
        videoSubtitleCell.selectionStyle = UITableViewCellSelectionStyleNone;
        return videoSubtitleCell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (tableView == self.relatedTableView) {
        return UITableViewAutomaticDimension;
    }
    else {
        return 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForHeaderInSection:(NSInteger)section {
    if (tableView == self.relatedTableView) {
        if (section == 0) {
            return 80;
        }
        return 45;
    }
    else {
        return 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (tableView == self.relatedTableView) {
        if (section == 0) {
            return 10;
        }
        return 0;
    }
    else {
        return 0;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (tableView == self.relatedTableView) {
        VSVideoCourse *tempVideoCourse = self.relatedDatas[indexPath.row];
        VSVideoCourseViewController *videoCourseViewController = [VSVideoCourseViewController new];
        videoCourseViewController.masterCourseId = [NSString stringWithFormat:@"%ld", (long)tempVideoCourse.id];
        [self.navigationController pushViewController:videoCourseViewController animated:YES];
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if (vc == self) {
                NSMutableArray *vcs = [self.navigationController.viewControllers mutableCopy];
                [vcs removeObject:vc];
                self.navigationController.viewControllers = [vcs copy];
                break;
            }
        }
    }
    else {
        NSTimeInterval seektime = [self.subtitleDatas[indexPath.row].stTime timeIntervalSince1970];
        [self.player seekToTime:seektime+1 completionHandler:nil];
        NSLog(@"--------seekto--%.1f", seektime);
    }
}

#pragma mark- VideoPlayer Horizontal
- (UIStatusBarAnimation)preferredStatusBarUpdateAnimation {
    return UIStatusBarAnimationSlide;
}

- (BOOL)shouldAutorotate {
    NSLog(@"----%id",self.player.shouldAutorotate);
    return self.player.shouldAutorotate;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

#pragma mark- lazy

- (void)setSubtitleDatas:(NSArray<VSVideoLRC *> *)subtitleDatas {
    _subtitleDatas = subtitleDatas;
    [self.subtitleTableView reloadData];
}

// 是否有字幕
- (void)setHasSubtitle:(BOOL)hasSubtitle {
    _hasSubtitle = hasSubtitle;
    if (_hasSubtitle) {
        self.switchView.hidden = NO;
        if (self.hasSubtitle == YES) {
            [self setupVideoSubtitleTableView];
        }
    }
    else {
        self.switchView.hidden = YES;
    }
}

- (ZFPlayerControlView *)controlView {
    if (!_controlView) {
        _controlView = [ZFPlayerControlView new];
        _controlView.prepareShowLoading = YES;
    }
    return _controlView;
}

- (NSMutableArray<VSVideoCourse *> *)relatedDatas {
    if (!_relatedDatas) {
        _relatedDatas = [NSMutableArray array];
    }
    return _relatedDatas;
}

- (void)dealloc {
    [self uploadVideoProgerss];
    [self.player stop];
    self.player = nil;
}

@end
