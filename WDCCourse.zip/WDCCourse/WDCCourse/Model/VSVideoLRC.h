//
//  VSVideoLRC.h
//  VSchool
//
//  Created by liguoliang on 2020/2/13.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VSVideoLRC : NSObject
@property (nonatomic) NSDate *stTime;
@property (nonatomic) NSDate *edTime;
@property (nonatomic) NSString *content;
@end

NS_ASSUME_NONNULL_END
