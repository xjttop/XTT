//
//  VSVideoCourse.m
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSVideoCourse.h"

@implementation VSProcessDot
@end

@implementation VSVideoCourse
+ (NSDictionary *)modelContainerPropertyGenericClass {
    return @{@"processDots" : [VSProcessDot class]};
}
@end
