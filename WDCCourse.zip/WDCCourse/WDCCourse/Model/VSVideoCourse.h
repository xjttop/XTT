//
//  VSVideoCourse.h
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VSKnowledgeVideoPoint.h"
#import "VSTeacher.h"

@interface VSProcessDot : NSObject
@property (nonatomic) NSString *content;
@property (nonatomic) NSString *picture;
@property (nonatomic) NSInteger time;   // 时间点（秒计)
@end

@interface VSVideoCourse : NSObject

@property (nonatomic) NSInteger id;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *audio;
@property (nonatomic) NSString *video;
@property (nonatomic) NSString *cover;
/** 学习人数 */
@property (nonatomic) NSInteger learnedCount;
/** 总时长 (秒计) */
@property (nonatomic) NSInteger totalTimeLength;
/** 服务器时间 */
@property (nonatomic) NSInteger systemTime;
@property (nonatomic) VSTeacher *teacher;
/** 知识点信息 */
@property (nonatomic) VSKnowledgeVideoPoint *knowledgePoint;

/** 是否有字幕 */
@property (nonatomic) BOOL subtitled;
/** 字幕文件地址 */
@property (nonatomic) NSString *subtitle;

/** 是否有打点 */
@property (nonatomic) BOOL targeted;
/** 打点信息 */
@property (nonatomic) NSArray<VSProcessDot *> *processDots;

@end
