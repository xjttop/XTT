//
//  VSSchool.m
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "VSSchool.h"

@implementation VSSchool

@end
