//
//  VSTeacher.h
//  VSchool
//
//  Created by liguoliang on 2020/1/15.
//  Copyright © 2020 Evil. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VSSchool.h"

@interface VSTeacher : NSObject
@property (nonatomic) NSInteger id;
@property (nonatomic) NSString *name;
@property (nonatomic) VSSchool *school;
@end
