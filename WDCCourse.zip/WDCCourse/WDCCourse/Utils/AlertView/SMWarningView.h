//
//  MessagePushViewController.h
//  CMS
//
//  Created by 宋彬彬 on 16/3/7.
//  Copyright © 2016年 coactsoft_mac1. All rights reserved.
//

/*
 使用此显示控件时需在info.plist里添加 View controller-based status bar appearance = NO 字段
 */
#import <UIKit/UIKit.h>

@interface SMWarningView : NSObject

typedef void (^clickPrompt)(id _Nonnull userInfo);


+ (nonnull instancetype)sharedManager;

- (UIViewController *)getCurrentViewController;

/**
 *  显示警告消息
 *
 *  @param string 显示的内容
 */
- (void)displayWarningWithString:(nonnull NSString *)string;
- (void)displayPromptWithString:(NSString *)string color:(UIColor *)backgroundColor;
/**
 *  显示提示消息
 *
 *  @param string 显示的内容
 */
- (void)displayPromptWithString:(nonnull NSString *)string;

/**
 显示提示消息

 @param string 显示的内容
 @param userInfo 附加信息
 @param block 点击消息回调
 */
- (void)displayPromptWithString:(NSString *)string userInfo:(id)userInfo color:(UIColor *)backgroundColor clickPrompt:(clickPrompt)block;

/**
 *  显示无网络状态
 */
- (void)showNotReachable;

/**
 *  隐藏无网络状态
 */
- (void)hiddenNotReachable;

@end
