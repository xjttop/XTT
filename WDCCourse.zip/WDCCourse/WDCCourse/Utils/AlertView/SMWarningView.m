//
//  MessagePushViewController.m
//  CMS
//
//  Created by 宋彬彬 on 16/3/7.
//  Copyright © 2016年 coactsoft_mac1. All rights reserved.
//

#import "SMWarningView.h"

//获取屏幕尺寸
#define SM_SCREEN_WIDTH     [[UIScreen mainScreen] bounds].size.width
#define SM_SCREEN_HEIGHT    [[UIScreen mainScreen] bounds].size.height

#define SM_IS_IPHONE_X \
({BOOL iPhoneX = NO;\
if (UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPhone) {\
if (@available(iOS 11.0, *)) {\
iPhoneX = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0;\
}\
}\
(iPhoneX);})

//statusbar默认高度 orginal
#define SM_STATUSBAR_HEIGHT  (SM_IS_IPHONE_X ? (44) : 20 )

//导航栏原始高度
#define SM_NAVNORMAL_HEIGHT 44.0f

#define SM_EASYSHOWSAFE_BOTTOMMARGIN  (SM_IS_IPHONE_X ? 34.0f : 0.0f )

//状态栏高度
#define SM_NAVIGATION_HEIGHT (SM_STATUSBAR_HEIGHT + SM_NAVNORMAL_HEIGHT)

//显示时长
#define DISPLAY_TIME_INTERVAL 5
//动画持续时间
#define ANIMATION_TIME_INTERVAL .5f


@interface SMWarningView ()

@property (nonatomic, weak) UIView *backgroundView;//!< 背景视图
@property (nonatomic, weak) NSTimer *closeTime;//!< 定时器(用于定时关闭动画，定时关闭视图)
@property (nonatomic) NSInteger statusBarStyle;//!< 状态栏当前状态
@property (nonatomic) NSInteger viewStyle;//!< 当前页面 0=警告  1=提示
@property (nonatomic, weak) UIView *notReachableView;//!< 自定义无网络时提示样式
@property (nonatomic) id userInfo;//
@property (nonatomic, weak) clickPrompt block;//点击block
@end

@implementation SMWarningView

+ (instancetype)sharedManager {
    static SMWarningView *alertView;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        alertView = [[self alloc] init];
        alertView.statusBarStyle = NSNotFound;
        alertView.viewStyle = NSNotFound;
    });
    return alertView;
}
- (UIViewController *)getCurrentViewController {
    UIViewController *resultVC;
    resultVC = [self getCurrentViewController:[[UIApplication sharedApplication].keyWindow rootViewController]];
    while (resultVC.presentedViewController) {
        resultVC = [self getCurrentViewController:resultVC.presentedViewController];
    }
    return resultVC;
}

- (UIViewController *)getCurrentViewController:(UIViewController *)vc {
    if ([vc isKindOfClass:[UINavigationController class]]) {
        return [self getCurrentViewController:[(UINavigationController *)vc topViewController]];
    } else if ([vc isKindOfClass:[UITabBarController class]]) {
        return [self getCurrentViewController:[(UITabBarController *)vc selectedViewController]];
    } else {
        return vc;
    }
}
#pragma mark - 显示警告视图
- (void)displayWarningWithString:(NSString *)string {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *rootVC = [self getCurrentViewController];
        //设置状态栏颜色
//        if (self.statusBarStyle == NSNotFound) {
//            self.statusBarStyle = [UIApplication sharedApplication].statusBarStyle;
//            if (self.statusBarStyle == NSNotFound) {
//                self.statusBarStyle = 0;
//            }
//        }
//        if (!self.notReachableView) {//如果没有无网络界面
//            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
//        }
        //如果有视图就删除
        if (self.backgroundView) {
            [self.backgroundView removeFromSuperview];
            self.backgroundView = nil;
        }
        
        //设置页面类型
        self.viewStyle = 0;
        
        //创建提示视图
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, -SM_NAVIGATION_HEIGHT, SM_SCREEN_WIDTH, SM_NAVIGATION_HEIGHT)];
        bgView.backgroundColor = [UIColor colorWithRed:0.99 green:0.43 blue:0.44 alpha:1.00];
        bgView.layer.shadowColor=[UIColor blackColor].CGColor;
        bgView.layer.shadowOffset=CGSizeMake(0, 1);
        bgView.layer.shadowOpacity=0.5;
        
        UISwipeGestureRecognizer * recognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(slideBgView)];
        [recognizer setDirection:(UISwipeGestureRecognizerDirectionUp)];
        [bgView addGestureRecognizer:recognizer];
        
        UIFont *font = [UIFont systemFontOfSize:14 weight:.2];
        
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:font,NSFontAttributeName, nil];
        
        //width = 全屏-图片宽度-头/尾预留距离-距离文字的距离
        CGSize size = [string boundingRectWithSize:CGSizeMake(SM_SCREEN_WIDTH-20-16-8, 30) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
        
        NSString *mainBundle = [[NSBundle mainBundle] pathForResource:@"SMResouce" ofType:@"bundle"];
        NSString *path = [mainBundle stringByAppendingPathComponent:@"QUIIconWarning.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:path]];
        imageView.frame = CGRectMake(SM_SCREEN_WIDTH/2-size.width/2-8-10, SM_STATUSBAR_HEIGHT+12, 20, 20);
        [bgView addSubview:imageView];
        
        //提示内容displayStr
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(SM_SCREEN_WIDTH/2-size.width/2+10, SM_NAVIGATION_HEIGHT-44, size.width, 44)];
        titleLabel.textColor = [UIColor whiteColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        titleLabel.text = string;
        titleLabel.font = font;
        titleLabel.numberOfLines = 2;
        [bgView addSubview:titleLabel];
        
        if (self.notReachableView) {
            [rootVC.view.window insertSubview:bgView belowSubview:self.notReachableView];
        } else {
            [rootVC.view.window addSubview:bgView];
        }
        
        //发出beginAnimations请求，标志着UIView动画的开始，在和他commitAnimations请求的之间，可定义动画的展现方式
        [UIView beginAnimations:@"WarningAnimation" context:NULL];
        //设置动画时长
        [UIView setAnimationDuration:ANIMATION_TIME_INTERVAL];
        //设置动画播放数度类型
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        
        CGRect rect    = bgView.frame;
        rect.origin.y  = 0;
        bgView.frame = rect;
        
        [UIView commitAnimations];
        
        self.backgroundView = bgView;
        
        //如果有定时器删除当前定时器
        if (self.closeTime) {
            [self.closeTime invalidate];
            self.closeTime = nil;
        }
        //延迟几秒后执行删除
        NSTimer *time = [NSTimer scheduledTimerWithTimeInterval:DISPLAY_TIME_INTERVAL target:self selector:@selector(closeAnimation) userInfo:nil repeats:NO];
        self.closeTime = time;
    });
}

#pragma mark - 显示提示视图
- (void)displayPromptWithString:(NSString *)string {
    [self displayPromptWithString:string userInfo:nil color:nil clickPrompt:nil];
}
- (void)displayPromptWithString:(NSString *)string color:(UIColor *)backgroundColor {
    [self displayPromptWithString:string userInfo:nil color:backgroundColor clickPrompt:nil];
}
- (void)displayPromptWithString:(NSString *)string userInfo:(id)userInfo color:(UIColor *)backgroundColor clickPrompt:(clickPrompt)block {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.userInfo = userInfo;
        self.block = block;
        //    UIWindow *window = [[UIApplication sharedApplication].delegate window];
        //    UIViewController *rootVC = window.rootViewController;
        UIViewController *rootVC = [self getCurrentViewController];
        
        //设置状态栏颜色
//        if (self.statusBarStyle == NSNotFound) {
//            self.statusBarStyle = [UIApplication sharedApplication].statusBarStyle;
//            if (self.statusBarStyle == NSNotFound) {
//                self.statusBarStyle = 0;
//            }
//        }
//        if (!self.notReachableView) {//如果没有无网络界面
//            [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
//        }
        //如果有视图就删除
        if (self.backgroundView) {
            [self.backgroundView removeFromSuperview];
            self.backgroundView = nil;
        }
        
        //设置页面类型
        self.viewStyle = 1;
        
        //创建提示视图
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, -SM_NAVIGATION_HEIGHT, SM_SCREEN_WIDTH, SM_NAVIGATION_HEIGHT)];
        if(backgroundColor){
            bgView.backgroundColor = backgroundColor;
        }else{
            bgView.backgroundColor = [UIColor whiteColor];
        }
        bgView.layer.shadowColor=[UIColor blackColor].CGColor;
        bgView.layer.shadowOffset=CGSizeMake(0, 1);
        bgView.layer.shadowOpacity=0.5;
        
        //单击手势
        UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickBgView)];
        [bgView addGestureRecognizer:singleTap];
        
        UISwipeGestureRecognizer * recognizer = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(slideBgView)];
        [recognizer setDirection:(UISwipeGestureRecognizerDirectionUp)];
        [bgView addGestureRecognizer:recognizer];
        
        UIFont *font = [UIFont systemFontOfSize:14 weight:.2];
        
        //提示内容displayStr
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, SM_NAVIGATION_HEIGHT-44, SM_SCREEN_WIDTH - 30, 44)];
        titleLabel.textColor = [UIColor blackColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.text = string;
        titleLabel.font = font;
        [bgView addSubview:titleLabel];
        
        if (self.notReachableView) {
            [rootVC.view.window insertSubview:bgView belowSubview:self.notReachableView];
        } else {
            [rootVC.view.window addSubview:bgView];
        }
        
        //发出beginAnimations请求，标志着UIView动画的开始，在和他commitAnimations请求的之间，可定义动画的展现方式
        [UIView beginAnimations:@"PromptAnimation" context:NULL];
        //设置动画时长
        [UIView setAnimationDuration:ANIMATION_TIME_INTERVAL];
        //设置动画播放数度类型
        [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
        
        CGRect rect    = bgView.frame;
        rect.origin.y  = 0;
        bgView.frame = rect;
        
        [UIView commitAnimations];
        
        self.backgroundView = bgView;
        
        //如果有定时器删除当前定时器
        if (self.closeTime) {
            [self.closeTime invalidate];
            self.closeTime = nil;
        }
        //延迟几秒后执行删除
        NSTimer *time = [NSTimer scheduledTimerWithTimeInterval:DISPLAY_TIME_INTERVAL target:self selector:@selector(closeAnimation) userInfo:nil repeats:NO];
        self.closeTime = time;
    });
}
//点击提示页面
- (void)clickBgView {
    if (self.block) {
        self.block(self.userInfo);
        if (self.closeTime) {
            [self.closeTime invalidate];
            self.closeTime = nil;
        }
        [self closeAnimation];
    }
}
//滑动页面
- (void)slideBgView {
    if (self.closeTime) {
        [self.closeTime invalidate];
        self.closeTime = nil;
    }
    [self closeAnimation];
}
//关闭动画
- (void)closeAnimation {
    [UIView beginAnimations:@"PromptAnimation" context:NULL];
    //设置动画时长
    [UIView setAnimationDuration:ANIMATION_TIME_INTERVAL];
    //设置动画播放数度类型
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    CGRect rect    = self.backgroundView.frame;
    rect.origin.y  = -SM_NAVIGATION_HEIGHT;
    self.backgroundView.frame = rect;
    
    [UIView commitAnimations];
    //延迟几秒后执行删除
    NSTimer *time = [NSTimer scheduledTimerWithTimeInterval:ANIMATION_TIME_INTERVAL target:self selector:@selector(removeView) userInfo:nil repeats:NO];
    self.closeTime = time;
}
//删除视图
- (void)removeView {
    //暂停定时器
    [self.closeTime invalidate];
    self.closeTime = nil;
    //删除页面
    [self.backgroundView removeFromSuperview];
    self.backgroundView = nil;
    
    self.viewStyle = NSNotFound;
    //设置状态栏颜色
//    if (!_notReachableView) {//如果没有无网络界面
//        [UIApplication sharedApplication].statusBarStyle = self.statusBarStyle;
//        self.statusBarStyle = NSNotFound;
//    }
}

#pragma mark - 网络波动显示
//显示无网络状态
- (void)showNotReachable {
    if (_notReachableView) {
        return;
    }
    UIWindow *window = [[UIApplication sharedApplication].delegate window];
    UIViewController *rootVC = window.rootViewController;
    //设置状态栏颜色
//    if (self.statusBarStyle == NSNotFound) {
//        self.statusBarStyle = [UIApplication sharedApplication].statusBarStyle;
//        if (self.statusBarStyle == NSNotFound) {
//            self.statusBarStyle = 0;
//        }
//    }
//    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    
    //创建提示视图
    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, -SM_NAVIGATION_HEIGHT, SM_SCREEN_WIDTH, SM_NAVIGATION_HEIGHT)];
    bgView.backgroundColor = [UIColor colorWithRed:0.99 green:0.93 blue:0.73 alpha:1.00];
    bgView.layer.shadowColor=[UIColor blackColor].CGColor;
    bgView.layer.shadowOffset=CGSizeMake(0, 1);
    bgView.layer.shadowOpacity=0.5;
    
    UIFont *font = [UIFont systemFontOfSize:14 weight:.13];
    
    NSString *mainBundle = [[NSBundle mainBundle] pathForResource:@"SMResouce" ofType:@"bundle"];
    NSString *path = [mainBundle stringByAppendingPathComponent:@"icon_warning.png"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:path]];
    imageView.frame = CGRectMake(15, SM_NAVIGATION_HEIGHT+9.5, 25, 25);
    [bgView addSubview:imageView];
    
    //提示内容displayStr
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(imageView.frame)+10, SM_NAVIGATION_HEIGHT-44, SM_SCREEN_WIDTH, 44)];
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.text = @"网络不给力，请检查网络设置";
    titleLabel.font = font;
    [bgView addSubview:titleLabel];
    
    NSString *intoPath = [mainBundle stringByAppendingPathComponent:@"icon_into_gray.png"];
    UIImageView *intoImageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:intoPath]];
    intoImageView.tintColor = [UIColor colorWithRed:0.78 green:0.78 blue:0.80 alpha:1.00];
    intoImageView.frame = CGRectMake(SM_SCREEN_WIDTH - 14 - 15, SM_NAVIGATION_HEIGHT+14.5, 14, 15);
    [bgView addSubview:intoImageView];
    
    if (_backgroundView) {
        
    } else {
        [window addSubview:bgView];
    }
    
    //发出beginAnimations请求，标志着UIView动画的开始，在和他commitAnimations请求的之间，可定义动画的展现方式
    [UIView beginAnimations:@"notReachableAnimation" context:NULL];
    //设置动画时长
    [UIView setAnimationDuration:ANIMATION_TIME_INTERVAL];
    //设置动画播放数度类型
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    CGRect windowRect = rootVC.view.frame;
    windowRect.origin.y  = SM_NAVIGATION_HEIGHT;
    rootVC.view.frame = windowRect;
    
    CGRect rect    = bgView.frame;
    rect.origin.y  = 0;
    bgView.frame = rect;
    
    [UIView commitAnimations];
    
    self.notReachableView = bgView;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onTouchUpInside)];
    [_notReachableView addGestureRecognizer:tapGesture];
    
    [[[UIApplication sharedApplication].delegate window] addSubview:_notReachableView];
}

//隐藏无网络状态
- (void)hiddenNotReachable {
    //获取Window
    UIWindow *window = [[UIApplication sharedApplication].delegate window];
    UIViewController *rootVC = window.rootViewController;
    
    CGRect windowRect = rootVC.view.frame;
    windowRect.origin.y  = 0;
    rootVC.view.frame = windowRect;
    
    //删除页面
    [_notReachableView removeFromSuperview];
    _notReachableView = nil;
    
    //设置状态栏颜色
//    if (self.viewStyle == 0) {
//        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
//    } else if (self.viewStyle == 1) {
//        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
//    } else {
//        [UIApplication sharedApplication].statusBarStyle = self.statusBarStyle;
//        self.statusBarStyle = NSNotFound;
//    }
}

- (void)onTouchUpInside {
    NSURL*url=[NSURL URLWithString:UIApplicationOpenSettingsURLString];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        [[UIApplication sharedApplication] openURL:url];
    }
}

/* 仿安卓显示样式
 
 //创建提示视图
 UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(SM_SCREEN_WIDTH/2 - 120, SM_SCREEN_HEIGHT-100, 240, 40)];
 bgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.8];
 bgView.alpha = 0;
 bgView.layer.masksToBounds = YES;
 bgView.layer.cornerRadius = 6;
 
 //提示内容displayStr
 UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(13, CGRectGetHeight(bgView.frame)-40, CGRectGetWidth(bgView.frame)-30, 40)];
 titleLabel.textColor = [UIColor whiteColor];
 titleLabel.textAlignment = NSTextAlignmentCenter;
 titleLabel.text = @"网络不给力，请检查网络设置";
 titleLabel.font = [UIFont systemFontOfSize:14];
 [bgView addSubview:titleLabel];
 
 NSString *mainBundle = [[NSBundle mainBundle] pathForResource:@"SMResouce" ofType:@"bundle"];
 NSString *path = [mainBundle stringByAppendingPathComponent:@"icon_into_white.png"];
 UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:path]];
 imageView.frame = CGRectMake(CGRectGetWidth(titleLabel.frame)+8, 13, 14, 14);
 [bgView addSubview:imageView];
 
 _notReachableView = bgView;
 
 //0.2秒后显示出来
 [UIView animateWithDuration:0.2 animations:^{
 bgView.alpha = 1;
 }];
 */

@end
