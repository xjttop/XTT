//
//  UIColor+SMAddition.h
//  BasicFramework
//
//  Created by 宋彬彬 on 2016/12/28.
//  Copyright © 2016年 EvilProduce. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (SMAddition)

/**
 使用 16 进制数字创建颜色，例如 0xFF0000 创建红色

 @param hex 16进制无符号32位整数
 @return 颜色
 */
+ (instancetype)colorWithHex:(uint32_t)hex;

/**
 使用16进制字符创建颜色，例如 @"#FF0000" 创建红色

 @param hexStr 16进制字符
 @return 颜色
 */
+ (instancetype)colorWithHexString:(NSString *)hexStr;

/**
 生成随机颜色

 @return 随机颜色
 */
+ (instancetype)colorRandom;

@end
