//
//  NSArray+LRCStrExt.m
//  VSchool
//
//  Created by liguoliang on 2020/2/13.
//  Copyright © 2020 Evil. All rights reserved.
//

#import "NSArray+LRCStrExt.h"


@implementation NSArray (LRCStrExt)
+ (NSArray<VSVideoLRC *> *)createWithLRCString:(NSString *)lrcStr {
    NSArray *temp = [lrcStr componentsSeparatedByString:@"\n"];
    NSMutableArray *result = [NSMutableArray arrayWithCapacity:temp.count];
    for(int i=0;i<temp.count;i++){
        NSArray *element = [temp[i] componentsSeparatedByString:@"|"];
        if(element.count<3){
            continue;
        }
        VSVideoLRC *lrc = [VSVideoLRC new];
        NSDateFormatter *df = [[NSDateFormatter alloc]init];
        df.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
        df.dateFormat = @"HH:mm:ss:SSS";
        df.defaultDate = [NSDate dateWithTimeIntervalSince1970:0];
        lrc.stTime = [df dateFromString:element[0]];
        lrc.edTime = [df dateFromString:element[1]];
        lrc.content = element[2];
        [result addObject:lrc];
    }
    return [result copy];
}
@end
