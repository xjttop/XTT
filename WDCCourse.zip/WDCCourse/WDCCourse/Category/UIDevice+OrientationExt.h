//
//  UIDevice+OrientationExt.h
//  VSchool
//
//  Created by liguoliang on 2019/12/30.
//  Copyright © 2019 Evil. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIDevice (OrientationExt)

+ (void)OrientationTo:(UIInterfaceOrientation)interfaceOrientation;

@end

NS_ASSUME_NONNULL_END
