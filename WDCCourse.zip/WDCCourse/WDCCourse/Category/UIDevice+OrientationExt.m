//
//  UIDevice+OrientationExt.m
//  VSchool
//
//  Created by liguoliang on 2019/12/30.
//  Copyright © 2019 Evil. All rights reserved.
//

#import "UIDevice+OrientationExt.h"

@implementation UIDevice (OrientationExt)

+ (void)OrientationTo:(UIInterfaceOrientation)interfaceOrientation {
    NSNumber *resetOrientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationUnknown];
    [[UIDevice currentDevice] setValue:resetOrientationTarget forKey:@"orientation"];
    NSNumber *orientationTarget = [NSNumber numberWithInteger:interfaceOrientation];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];
}
@end
