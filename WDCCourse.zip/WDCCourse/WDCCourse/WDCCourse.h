//
//  WDCCourse.h
//  WDCCourse
//
//  Created by Xjt on 2020/11/11.
//

#import <Foundation/Foundation.h>

//! Project version number for WDCCourse.
FOUNDATION_EXPORT double WDCCourseVersionNumber;

//! Project version string for WDCCourse.
FOUNDATION_EXPORT const unsigned char WDCCourseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WDCCourse/PublicHeader.h>
#import <WDCCourse/VSVideoCourseViewController.h>
#import <WDCCourse/BackOffStyleViewController.h>
#import <WDCCourse/BaseViewController.h>
#import <WDCCourse/VSWebViewController.h>
